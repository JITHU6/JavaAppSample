/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangmannirmal;

import java.sql.DriverManager;
import java.sql.*;

/**
 *
 *
 * @author jithu
 */
public class DbConnect {
    private static Connection con=null;
    public DbConnect() {

    }

    public static Connection connection() {

        try {

            Class.forName("com.mysql.jdbc.driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Polls");

        } catch (Exception e) {
            System.out.println(e);

        }
        return con;
    }

}
