/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangmannirmal;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author jithu
 */
public class WordSelectorDb implements WordProvider{
    public String word;
    List<String> li=new ArrayList<String>();
    Connection con;
   
    public WordSelectorDb() throws SQLException{
        con=DbConnect.connection();
    }  
    
    
    @Override
    public boolean hasNext() {
        if(li.isEmpty()){
            return false;
        }
        return true;
    }

    @Override
    public String Next() {        
        try{
            Statement stmt=con.createStatement();
            ResultSet re=stmt.executeQuery("select * from textword");
            while(re.next()){

                    li.add(re.getString(2));


            }
         }catch(SQLException e){
             System.out.println("e");
         }
        word = li.get(new Random().nextInt(li.size()));
        li.remove(word);

        return word;
    }
    
    
}
