/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangmannirmal;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author jithu
 */
public class WordSelectorFile implements WordProvider {
    File file = new File("/home/jithu/NetBeansProjects/JavaLearning/textfiles/abc.txt");
    Scanner sc;  
    Scanner scanner = new Scanner(System.in);
    public WordSelectorFile() throws FileNotFoundException {
        this.sc = new Scanner(file);
    }
    
    @Override
    public boolean hasNext() {
        if(!(sc.hasNext())){
            return false;
        }
        return true;
    }

    @Override
    public String Next(){
          String word = sc.nextLine();
          return word;
    }
    
}
