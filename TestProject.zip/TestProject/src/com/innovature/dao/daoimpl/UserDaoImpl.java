/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovature.dao.daoimpl;
import java.sql.*;
import java.util.*;
import com.innovature.jdbc.helper.DbHelper;
import com.innovature.entity.User;
import com.innovature.dao.userDao;
/**
 *
 * @author jithu
 */
public class UserDaoImpl implements userDao {
 Connection conn;   
 public UserDaoImpl(){
     conn=DbHelper.DBConnect();
 }
 public void createUser(User u){
     PreparedStatement prst=null;
     ResultSet rest=null;
     try{
         Integer userId=u.getUserId();
         String sql="select * from users where userid="+userId;
         prst=conn.prepareStatement(sql);
        rest=prst.executeQuery(sql);
        if(rest.next()){
            System.out.print("already exists");
        }else{
            String s="insert into   users(userid,username,userage) values("+u.getUserId()+",'"+u.getUserName()+"',"+u.getUserAge()+")";
            prst=conn.prepareStatement(s);
            prst.executeUpdate();
            System.out.println("User"+u.getUserId()+"created");
        }
     }catch(SQLException| RuntimeException se){
         se.printStackTrace();
     }finally{
                try{
                    if(prst==null)
                    conn.close();
                    }catch(SQLException se){
                    System.out.println(se.getCause());
                    }
            }
 }
 public void updateUser(Integer userId,User u){
     PreparedStatement prst=null;
     
     ResultSet rest=null;
     try{
        
          String s="select * from users where userid="+u.getUserId();
     prst=conn.prepareStatement(s);
     rest=prst.executeQuery(s);
     
     if(rest.next()){
         String d="update users set username="+u.getUserName()+",userage="+u.getUserAge();
         prst=conn.prepareStatement(d);
         prst.executeUpdate();
         System.out.print("User"+u.getUserId()+"updated");
     }else{
         System.out.print("not a valid userid");
     }
     }catch(SQLException|RuntimeException se){
         se.printStackTrace();
     }finally{
         try{
             
             if(prst==null){
                 conn.close();
             }
                 
             }catch(SQLException se){
                     System.out.println(se.getCause());
         }
     }
 }
 public void deleteUser(Integer userId){
        PreparedStatement stmt=null;
        ResultSet rslt=null;
        try{
            String sql="select * from users where userid="+userId;
            stmt = conn.prepareStatement(sql);
            rslt = stmt.executeQuery();
            if(rslt.next()){
                String s="delete from users where userid= "+userId;
                System.out.println(s);
                stmt=conn.prepareStatement(s);
                stmt.executeUpdate();
                System.out.println("User deleted");   
            }
            else{
                System.out.println("User not found, please confirm User Id");
            }
        }catch(SQLException | RuntimeException se){
            se.printStackTrace();
        }finally{
                try{
                    if(stmt==null)
                    conn.close();
                    }catch(SQLException se){
                    System.out.println(se.getCause());
                    }
        }
    }
 @Override
 public List<User> readAllUser(){
     List<User> list=new ArrayList();
     PreparedStatement prst=null;
     ResultSet re=null;
     try{
     String s="select * from users";
     prst=conn.prepareStatement(s);
     re=prst.executeQuery();
     System.out.print("id\tname\tage\t");
     while(re.next()){
         System.out.println("%d\t%s\t%d");
         re.getInt(2);
         re.getString(3);
         re.getInt(4);
         
     }
     
 }catch(SQLException|RuntimeException se){
     se.printStackTrace();
        }finally{
                try{
                    if(prst==null){
                        conn.close();
                    }
                }catch(SQLException se){
                    System.out.print(se.getCause());
                }
            }
     return list;
}

    
 
}