/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovature.dao;
import com.innovature.entity.User;
import java.util.List;
/**
 *
 * @author jithu
 */
public interface userDao {
    void createUser(User u);
    void updateUser(Integer userId,User u);
    void deleteUser(Integer userId);
    List<User> readAllUser();
}
