/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovature.entity;

/**
 *
 * @author jithu
 */
public class User {
    private Integer userId;
    private String userName;
    private Integer userAge;
    
    public  User(Integer userId,String userName,Integer userAge){
    this.userId=userId;
    this.userName=userName;
    this.userAge=userAge;
    }
    public Integer getUserId(){
        return userId;
    }
    public void setUserId(Integer userId){
        this.userId=userId;
    }
    public String getUserName(){
        return userName;
    }
    public void setUserName(String name){
        this.userName=name;
    }
    public Integer getUserAge(){
        return userAge;
    }
    public void setUserAge(Integer age){
        this.userAge=age;
    }
    
    
}
