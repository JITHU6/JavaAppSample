/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovature.service.impl;
import com.innovature.service.UserServ;
import java.util.Scanner;
import com.innovature.entity.User;
import com.innovature.dao.userDao;
import java.util.List;
/**
 *
 * @author jithu
 */

public class UserServImpl implements UserServ{
    private final userDao userDao;
    
    public UserServImpl(userDao userDao){
        this.userDao=userDao;
    }
    public void createUser(){
        Scanner in=new Scanner(System.in);
        System.out.println("Enter useId");
        Integer userId=in.nextInt();
        System.out.print("enter name");
        String userName=in.next();
        System.out.print("enter age");
        Integer userAge=in.nextInt();
        User user=new User(userId,userName,userAge);
        userDao.createUser(user);
    }
    public void updateUser(){
        Scanner in=new Scanner(System.in);
        System.out.println("Enter useId");
        int userId=in.nextInt();
        System.out.println("Enter Updated name");
        String userName=in.next();
        System.out.println("Enter updated age");
        int userAge=in.nextInt();
        
        User user=new User(userId,userName,userAge);
        userDao.updateUser(userId, user);
    }
    public void deleteUser(){
        Scanner in=new Scanner(System.in);
        System.out.println("Enter useId");
        int userId=in.nextInt();
        userDao.deleteUser(userId);
    }
    public List<User> readAllUser(){
        return userDao.readAllUser();
    }
}
