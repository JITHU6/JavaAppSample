/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.innovature.test;
import com.innovature.service.UserServ;
import java.util.Scanner;
import com.innovature.dao.daoimpl.UserDaoImpl;
import com.innovature.service.impl.UserServImpl;
import com.innovature.entity.User;
import java.util.List;
/**
 *
 * @author jithu
 */
public class Main {
    private  final UserServ userserv;
    public Main(UserServ userserv){
        this.userserv=userserv;
    }
    public static void main(String[] args) {
        new Main(new UserServImpl(new UserDaoImpl())).run();
    }
    public void run(){
        Scanner in=new Scanner(System.in);
        System.out.print("Choose an option\t");
        System.out.println("1.Create user");
        System.out.println("2.Update user");
        System.err.println("3.Delete user");
        System.err.println("4.View all users");
        System.err.println("5.Exit");
        
        int opt=in.nextInt();
        switch(opt){
        case 1:
            userserv.createUser();
            break;
        case 2:
            userserv.updateUser();
            break;
        case 3:
            userserv.deleteUser();
            break;
        case 4:
            userserv.readAllUser();
            break;
        case 5:
            System.exit(opt);
            break;
        default:
            break;
           
    }
    }
    private void readAllUser(){
        List<User> list=userserv.readAllUser();
        User user;
        long l=list.stream().count();
        for(int i=0;i<l;i++){
            user=list.get(i);
            System.out.println("Id"+user.getUserId());
            System.out.println("Name"+user.getUserName());
            System.out.println("Age"+user.getUserAge());
        }
    }
    
    
}
